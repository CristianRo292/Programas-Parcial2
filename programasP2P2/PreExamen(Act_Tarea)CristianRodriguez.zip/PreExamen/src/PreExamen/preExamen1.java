/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package PreExamen;

/**
 *
 * @author roc53
 */
public class preExamen1 {
    public static void main(String[] args) {
        preexamen objeto = new preexamen();
        objeto.setVisible(true);
    }
}
